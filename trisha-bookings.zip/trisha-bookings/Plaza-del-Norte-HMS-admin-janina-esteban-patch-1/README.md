# Plaza-del-Norte-HMS-admin

Username: admin

Password: 1234

or pwede rin kayo mag register

Install Command: npm init -y  

npm i express express-handlebars body-parser mongodb 

npm install express-session

Run command:
node app.js

Local URL:
http://localhost:3001/
